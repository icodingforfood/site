﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication1
{
    public  class Teacher:Person
    {
        public string Telephone { get; set; }
        public string Course { get; set; }

    }
}
