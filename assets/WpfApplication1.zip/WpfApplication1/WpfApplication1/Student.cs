﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication1
{
    public class Student:Person
    {
        public string Grade { get; set; }
        public string School { get; set; }
    }
}
